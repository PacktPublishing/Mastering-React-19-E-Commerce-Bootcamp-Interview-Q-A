import { useState } from "react";
import "./App.css";

function App() {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState();
  const [city, setCity] = useState("");
  const [data, setData] = useState("");

  const handleFirstNameChange = (e) => {
    setFirstName(e.target.value);
  }
  const handleLastNameChange = (e) => {
    setLastName(e.target.value);
  }

  const handlePhoneNumberChange = (e) => {
    setPhoneNumber(e.target.value);
  }

  const handleCityChange = (e) => {
    setCity(e.target.value);
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    setData(firstName + " " + lastName + ", " + phoneNumber + ", " + city);
  }

  return (
    <div>
      <form onClick={handleSubmit}>
        <input type="text" placeholder="Enter First Name" onChange={handleFirstNameChange} />
        <br />
        <input type="text" placeholder="Enter Last Name" onChange={handleLastNameChange} />
        <br />
        <input type="number" placeholder="Enter Phone Number" onChange={handlePhoneNumberChange} />
        <br />
        <input type="text" placeholder="Enter City" onChange={handleCityChange} />
        <br />
      </form>
      <button type="submit">Submit</button>
      <h3>{data}</h3>
    </div>
  );
}

export default App;
