import { useState } from "react";
import "./App.css";

function App() {
  const [data, setData] = useState({
    firstName: "",
    lastName: "",
    phoneNumber: "",
    city: ""
  });


  const handleFirstNameChange = (e) => {
    setData({ ...data, firstName: e.target.value });
  }
  const handleLastNameChange = (e) => {
    setData({ ...data, lastName: e.target.value });
  }
  const handlePhoneNumberChange = (e) => {
    setData({ ...data, phoneNumber: e.target.value });
  }
  const handleCityChange = (e) => {
    setData({ ...data, city: e.target.value });
  }


  const handleSubmit = (e) => {
    e.preventDefault();
  }

  return (
    <div>
      <form onClick={handleSubmit}>
        <input type="text" placeholder="Enter First Name" onChange={handleFirstNameChange} />
        <br />
        <input type="text" placeholder="Enter Last Name" onChange={handleLastNameChange} />
        <br />
        <input type="number" placeholder="Enter Phone Number" onChange={handlePhoneNumberChange} />
        <br />
        <input type="text" placeholder="Enter City" onChange={handleCityChange} />
        <br />
      </form>
      <button type="submit">Submit</button>
      <h3>{JSON.stringify(data)}</h3>
    </div>
  );
}

export default App;
