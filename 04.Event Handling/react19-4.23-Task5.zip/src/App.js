import { useState } from "react";
import "./App.css";

function App() {
  const [bgColor, setBgColor] = useState("");

  const handleChange = (e) => {
    setBgColor(e.target.value);
  };

  return (
    <div style={{ backgroundColor: bgColor }}>
      <input type="radio" onChange={handleChange} name="bgColor" value="blue" />
      <label>Blue</label>
      <input
        type="radio"
        onChange={handleChange}
        name="bgColor"
        value="green"
      />
      <label>Green</label>
      <input
        type="radio"
        onChange={handleChange}
        name="bgColor"
        value="yellow"
      />
      <label>Yellow</label>
      <input type="radio" onChange={handleChange} name="bgColor" value="red" />
      <label>Red</label>
    </div>
  );
}

export default App;
