import { useState } from "react";
import "./App.css";

function App() {
  const [data, setData] = useState({
    name: "",
    gender: "",
    isAgreed: false,
  });
  const [text, setText] = useState("");

  const handleInputChange = (e) => {
    setData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleCbChange = (e) => {
    setData((prev) => ({ ...prev, [e.target.name]: e.target.checked }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setText(`Hello, ${data.gender === "male" ? "Mr." : "Ms."} ${data.name}`);
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter Name"
          name="name"
          onChange={handleInputChange}
        />
        <br />
        <input
          type="radio"
          name="gender"
          value="male"
          onChange={handleInputChange}
        />
        <label>Male</label>
        <input
          type="radio"
          name="gender"
          value="female"
          onChange={handleInputChange}
        />
        <label>Female</label>
        <br />
        <input type="checkbox" name="isAgreed" onChange={handleCbChange} />
        <label>I Agree.</label>
        <br />
        <button type="submit" disabled={!data.isAgreed}>
          Submit
        </button>
      </form>
      <h1>{text}</h1>
    </div>
  );
}

export default App;
