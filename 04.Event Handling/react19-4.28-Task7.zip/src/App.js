import { useState } from "react";
import "./App.css";

function App() {
  const [isFocused, setIsFocused] = useState(false);

  const handleFocus = () => {
    setIsFocused(true);
  };

  const handleBlur = () => {
    setIsFocused(false);
  };

  return (
    <div>
      <input
        type="text"
        onFocus={handleFocus}
        onBlur={handleBlur}
        style={{ backgroundColor: isFocused ? "yellow" : "white" }}
      />
    </div>
  );
}

export default App;
