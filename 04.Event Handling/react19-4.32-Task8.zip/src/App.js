import { useState } from "react";
import "./App.css";

function App() {
  const [isHovered, setIsHovered] = useState(false);
  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  return (
    <div>
      <h1 onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
        Hello World!
      </h1>
      {isHovered && <div className="tooltip">Tooltip Rendered</div>}
    </div>
  );
}

export default App;
