import { useState } from "react";
import "./App.css";

function App() {
  const [inputText, setInputText] = useState("");
  const handleChange = (e) => {
    setInputText(e.target.value);
  }

  return (
    <div>
      <input type="text" onChange={handleChange} />
      <h1>{inputText}</h1>
    </div>
  );
}

export default App;
