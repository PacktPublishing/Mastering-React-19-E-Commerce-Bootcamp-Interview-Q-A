import { useState } from "react";
import "./App.css";
import AddProductModal from "./components/AddProductModal";
import ProductCard from "./components/ProductCard";

function App() {
  const [isOpen, setIsOpen] = useState(false);
  const [productList, setProductList] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState();

  const handleModalOpen = () => {
    setIsOpen(true);
  };
  const handleModalClose = () => {
    setIsOpen(false);
  }

  const handleAddProduct = (product) => {
    setProductList((prev) => [...prev, product]);
    handleModalClose();
  };

  const handleDeleteProduct = (productCode) => {
    setProductList((prev) =>
      prev.filter((product) => product.productCode !== productCode)
    );
  };

  const handleEditClick = (product) => {
    setSelectedProduct(product);
    setIsOpen(true);
  };

  return (
    <>
      <div className="w-full max-w-5xl mx-auto">
        <div className="flex justify-between items-center my-10">
          <h1 className="text-5xl font-bold">Products</h1>
          <button
            type="button"
            className="bg-blue-500 text-white py-2 px-4 rounded-md text-lg font-semibold"
            onClick={handleModalOpen}
          >
            Add Product
          </button>
        </div>
        <div className="grid grid-cols-4 -and- gap-4">
          {productList.length > 0 ? (
            productList.map((product) => (
              <ProductCard
                key={product.productCode}
                product={product}
                handleDeleteProduct={handleDeleteProduct}
                handleEditClick={handleEditClick}
              />
            ))
          ) : (
            <h3 className="text-center col-span-6 text-xl font-medium">
              No Product Found.
            </h3>
          )}

        </div>
      </div>
      {isOpen && (
        <AddProductModal
          handleModalClose={handleModalClose}
          handleAddProduct={handleAddProduct}
          selectedProduct={selectedProduct}
        />
      )}
    </>
  );
}

export default App;
