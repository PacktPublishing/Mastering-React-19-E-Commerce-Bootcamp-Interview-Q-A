import { useState } from "react";
import "./App.css";
import AddEditProductModal from "./components/AddEditProductModal";
import ProductCard from "./components/ProductCard";

function App() {
  const [isOpen, setIsOpen] = useState(false);
  const [productList, setProductList] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState();

  const handleModalOpen = () => {
    setIsOpen(true);
  };
  const handleModalClose = () => {
    setIsOpen(false);
    setSelectedProduct();
  }

  const handleAddProduct = (product) => {
    setProductList((prev) => [...prev, product]);
    handleModalClose();
  };

  const handleDeleteProduct = (productCode) => {
    setProductList((prev) =>
      prev.filter((product) => product.productCode !== productCode)
    );
  };

  const handleEditClick = (product) => {
    setSelectedProduct(product);
    setIsOpen(true);
  };

  const handleEditProduct = (product) => {
    const updatedProductList = productList.map((p) =>
      p.productCode === product.productCode ? product : p
    );
    setProductList(updatedProductList);
    handleModalClose();
  };


  return (
    <>
      <div className="w-full max-w-5xl mx-auto">
        <div className="flex justify-between items-center my-10">
          <h1 className="text-5xl font-bold">Products</h1>
          <button
            type="button"
            className="bg-blue-500 text-white py-2 px-4 rounded-md text-lg font-semibold"
            onClick={handleModalOpen}
          >
            Add Product
          </button>
        </div>
        <div className="grid grid-cols-4 -and- gap-4">
          {productList.length > 0 ? (
            <>
              {productList
                .filter((p) => p.isActive)
                .map((product) => (
                  <ProductCard
                    key={product.productCode}
                    product={product}
                    handleDeleteProduct={handleDeleteProduct}
                    handleEditClick={handleEditClick}
                  />
                ))}
              {productList
                .filter((p) => !p.isActive)
                .map((product) => (
                  <ProductCard
                    key={product.productCode}
                    product={product}
                    handleDeleteProduct={handleDeleteProduct}
                    handleEditClick={handleEditClick}
                  />
                ))}
            </>
          ) : (
            <h3 className="text-center col-span-6 text-xl font-medium">
              No Product Found.
            </h3>
          )}

        </div>
      </div>
      {isOpen && (
        <AddEditProductModal
          handleModalClose={handleModalClose}
          handleAddProduct={handleAddProduct}
          selectedProduct={selectedProduct}
          handleEditProduct={handleEditProduct}
        />
      )}
    </>
  );
}

export default App;
