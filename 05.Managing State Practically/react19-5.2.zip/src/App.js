import "./App.css";

function App() {
  return (
    <div className="w-full max-w-5xl mx-auto">
      <div className="flex justify-between items-center my-10">
        <h1 className="text-5xl font-bold">Products</h1>
        <button
          type="button"
          className="bg-blue-500 text-white py-2 px-4 rounded-md text-lg font-semibold"
        >
          Add Product
        </button>
      </div>
    </div>
  );
}

export default App;
