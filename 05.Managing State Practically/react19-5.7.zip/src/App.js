import { useState } from "react";
import "./App.css";
import AddProductModal from "./components/AddProductModal";
import ProductCard from "./components/ProductCard";

function App() {
  const [isOpen, setIsOpen] = useState(false);
  const productList = [
    {
      productCode: "001",
      productName: "Pineapple",
      price: 12,
    },
    {
      productCode: "002",
      productName: "Banana",
      price: 10,
    },
    {
      productCode: "003",
      productName: "Mango",
      price: 18,
    },
    {
      productCode: "004",
      productName: "Orange",
      price: 15,
    },
    {
      productCode: "005",
      productName: "Apple",
      price: 20,
    },
    {
      productCode: "006",
      productName: "Grapes",
      price: 25,
    },
  ]

  const handleModalOpen = () => {
    setIsOpen(true);
  };
  const handleModalClose = () => {
    setIsOpen(false);
  }

  return (
    <>
      <div className="w-full max-w-5xl mx-auto">
        <div className="flex justify-between items-center my-10">
          <h1 className="text-5xl font-bold">Products</h1>
          <button
            type="button"
            className="bg-blue-500 text-white py-2 px-4 rounded-md text-lg font-semibold"
            onClick={handleModalOpen}
          >
            Add Product
          </button>
        </div>
        <div className="grid grid-cols-4 -and- gap-4">
          {productList.map((product) => (
            <ProductCard key={product.productCode} product={product} />
          ))}
        </div>
      </div>
      {isOpen && <AddProductModal handleModalClose={handleModalClose} />}
    </>
  );
}

export default App;
