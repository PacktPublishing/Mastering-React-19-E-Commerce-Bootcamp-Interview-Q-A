import React, { useState } from 'react'

const AddProductModal = ({ handleModalClose }) => {
    const [data, setData] = useState({
        productCode: "",
        productName: "",
        price: "",
    });

    const handleInputChange = (e) => {
        setData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(data);
    };

    return (
        <div className="fixed inset-0 flex justify-center items-center z-50">
            <div className="fixed inset-0 bg-black opacity-50" />
            <div className="relative w-full max-w-xl bg-white rounded-lg p-10 shadow-lg text-xl">
                <button
                    type="button"
                    className="absolute top-2 right-5 text-3xl p-0 text-gray-400"
                    onClick={handleModalClose}
                >
                    &times;
                </button>
                <h1 className="text-4xl font-semibold - and - mb-6">
                    Add Product
                </h1>
                <form className="grid gap-5" onSubmit={handleSubmit}>
                    <div>
                        <label>Product Code:</label>
                        <input
                            className="w-full border rounded px-2 py-1"
                            type="text"
                            placeholder="Enter Product Code"
                            name="productCode"
                            onChange={handleInputChange}
                        />
                    </div>
                    <div>
                        <label className="font-medium">Product Name:</label>
                        <input
                            className="w-full border rounded px-2 py-1"
                            type="text"
                            placeholder="Enter Product Name"
                            name="productName"
                            onChange={handleInputChange}
                        />
                    </div>
                    <div>
                        <label className="font-medium">Price:</label>
                        <input
                            className="w-full border rounded px-2 py-1"
                            type="number"
                            placeholder="Enter Price"
                            name="price"
                            onChange={handleInputChange}
                        />
                    </div>
                    <button
                        type="submit"
                        className="bg-blue-500 text-white py-2 px-4 rounded-md font-semibold text-lg mt-6"
                    >
                        Submit
                    </button>
                </form>
            </div>
        </div>
    )
}

export default AddProductModal