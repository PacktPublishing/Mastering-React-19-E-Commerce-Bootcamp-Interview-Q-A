import { useParams } from "react-router";

const ProductDetails = () => {
    const { id } = useParams();
    return (
        <div>Product Details Component {JSON.stringify(id)}</div>
    )
}

export default ProductDetails;