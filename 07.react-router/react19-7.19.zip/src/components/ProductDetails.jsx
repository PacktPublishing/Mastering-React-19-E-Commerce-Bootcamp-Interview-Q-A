import { useOutletContext, useParams } from "react-router";

const ProductDetails = () => {
    const { id } = useParams();
    const productObj = useOutletContext();
    const selectedProduct = productObj.find((p) => p.id === id);
    return (
        <div>
            <h1>Product Details Component {JSON.stringify(id)}</h1>
            <h2>{JSON.stringify(selectedProduct)}</h2>
        </div>
    )
}

export default ProductDetails;