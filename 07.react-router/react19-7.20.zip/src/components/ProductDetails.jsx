import { useLocation, useOutletContext, useParams } from "react-router";

const ProductDetails = () => {
    const { id } = useParams();
    const location = useLocation();
    // const productObj = useOutletContext();
    // const selectedProduct = productObj.find((p) => p.id === id);
    return (
        <div>
            <h1>Product Details Component {JSON.stringify(id)}</h1>
            <h2>{JSON.stringify(location.state)}</h2>
        </div>
    )
}

export default ProductDetails;