import { useLocation, useOutletContext, useParams } from "react-router";

const ProductDetails = () => {
    const { id } = useParams();
    const { state } = useLocation();
    return (
        <div className="mx-6 max-w-[800px] mx-auto">
            <h1 className="text-3xl font-semibold">Selected Product</h1>
            <div className="border border-gray-50 rounded-md shadow-md p-2 bg-gray-200 grid grid-cols-4 mt-3">
                <img src={state.image} alt={state.name} className="h-[160px] w-[160px] col-span-1 p-3 object-contain" />
                <div className="flex flex-col gap-2 text-xl font-semibold col-span-3 my-auto">
                    <span>{state.name}</span>
                    <span>{state.description}</span>
                    <span>Price: ${state.price}</span>
                </div>
            </div>
        </div>
    )
}

export default ProductDetails;