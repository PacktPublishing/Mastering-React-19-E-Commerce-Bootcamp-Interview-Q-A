import './App.css';
import Home from './components/Home';
import Products from './components/Products';
import About from './components/About';
import { Link, Navigate, Route, Routes } from 'react-router';
import NotFound from './components/NotFound';
import ProductDetails from './components/ProductDetails';
import Layout from './components/Layout';

function App() {
  return (
    <div>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="/products" element={<Products />}>
            <Route path=":id" element={<ProductDetails />} />
          </Route>
          <Route path="/about" element={<About />} />
          <Route path="*" element={<Navigate to="/products" />} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;
