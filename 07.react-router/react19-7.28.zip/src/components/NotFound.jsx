import { useState } from "react";
import { Navigate, useNavigate } from "react-router";

const NotFound = () => {
    const navigate = useNavigate();
    const handleClick = () => {
        navigate(-1);
    }
    return (
        <div>
            <h1>404 Not Found.</h1>
            <button className="bg-blue-500 text-white px-3 py-1 rounded-md" onClick={handleClick}>
                Go Back
            </button>
        </div>
    )
}

export default NotFound;