import React from 'react'

const Products = () => {
    return (
        <div>Products Component</div>
    )
}

export default Products