import { useState } from "react";
import { Navigate, useNavigate } from "react-router";

const NotFound = () => {
    const navigate = useNavigate();
    const handleClick = () => {
        navigate(-1);
    }
    return (
        <div className="flex flex-col gap-4 justify-center items-center my-20">
            <h1 className="text-3xl font-semibold">404 Not Found.</h1>
            <button className="bg-blue-500 text-white px-3 py-1 rounded-md" onClick={handleClick}>
                Go Back
            </button>
        </div>
    )
}

export default NotFound;