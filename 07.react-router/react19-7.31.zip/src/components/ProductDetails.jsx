import { useLocation, useOutletContext, useParams } from "react-router";

const ProductDetails = () => {
    const { id } = useParams();
    const { state } = useLocation();
    return (
        <div className="mx-6 max-w-[800px] mx-auto">
            <div className="border border-neutral-50 rounded-md shadow-md bg-gray-200 grid grid-cols-3 mt-10">
                <img src={state.image} alt={state.name} className="h-[260px] w-[260px] col-span-1 object-cover rounded-l-md" />
                <div className="flex flex-col gap-2 col-span-2 my-auto px-5">
                    <span className="text-3xl font-semibold">{state.name}</span>
                    <span className="text-2xl font-medium">${state.price}</span>
                    <span className="text-md leading-5 text-neutral-500">{state.description}</span>
                </div>
            </div>
        </div>
    )
}

export default ProductDetails;