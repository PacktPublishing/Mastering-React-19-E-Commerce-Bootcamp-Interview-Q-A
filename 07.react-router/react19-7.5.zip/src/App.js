import { Link, Route, Routes } from "react-router";
import "./App.css";
import About from "./components/About";
import Home from "./components/Home";
import Products from "./components/Products";

function App() {
  return (
    <div>
      <ul className="flex gap-4">
        <li><Link to="/home">Home</Link></li>
        <li><Link to="/products">Products</Link></li>
        <li><Link to="/about">About</Link></li>
      </ul>
      <hr />
      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/products" element={<Products />} />
        <Route path="/about" element={<About />} />
      </Routes>
    </div>
  );
}

export default App;
