import logo from './logo.svg';
import './App.css';
import Home from './components/Home';
import Products from './components/Products';
import About from './components/About';
import { Link, Route, Routes } from 'react-router';
import NotFound from './components/NotFound';

function App() {
  return (
    <div>
      <ul className="flex gap-4 p-5 bg-gray-50 shadow-md font-semibold">
        <li><Link to="/">Home</Link></li>
        <li><Link to="/products">Products</Link></li>
        <li><Link to="/about">About</Link></li>
      </ul>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/products" element={<Products />} />
        <Route path="/about" element={<About />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </div>
  );
}

export default App;
