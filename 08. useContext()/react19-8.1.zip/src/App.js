import React from "react";
import "./App.css";
import ComponentA from "./components/ComponentA";

function App() {
  const str = "Hello World";
  return (
    <div>
      <ComponentA str={str} />
    </div>
  );
}

export default App;
