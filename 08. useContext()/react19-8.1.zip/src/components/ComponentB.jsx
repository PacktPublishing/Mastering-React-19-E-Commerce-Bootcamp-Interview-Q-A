import React from 'react'
import ComponentC from './ComponentC'

const ComponentB = ({ str }) => {
    return (
        <section className="sectionB">
            <span>ComponentB</span>
            <ComponentC str={str} />
        </section>
    )
}

export default ComponentB