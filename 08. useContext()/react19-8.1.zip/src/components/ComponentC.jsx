import React from 'react'
import ComponentD from './ComponentD'

const ComponentC = ({ str }) => {
    return (
        <section className="sectionC">
            <span>ComponentC</span>
            <ComponentD str={str} />
        </section>
    )
}

export default ComponentC