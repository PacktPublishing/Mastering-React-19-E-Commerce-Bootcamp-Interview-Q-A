import { useContext } from "react";
import { CalculatorContext } from "../store/CalculatorContext";

const CalculateSection = () => {
    const {
        calculateAddition,
        calculateSubtraction,
        calculateMultiplication,
        calculateDivision,
    } = useContext(CalculatorContext);
    console.log("Calculate section is rendered!");

    return (
        <div className="border rounded-md p-5 h-[250px] w-[300px] grid gap-3">
            <button type="button" className="bg-blue-500 text-white px-3 py-1 rounded-md" onClick={calculateAddition}>Add</button>
            <button type="button" className="bg-blue-500 text-white px-3 py-1 rounded-md" onClick={calculateSubtraction}>Subtract</button>
            <button type="button" className="bg-blue-500 text-white px-3 py-1 rounded-md" onClick={calculateMultiplication}>Multiply</button>
            <button type="button" className="bg-blue-500 text-white px-3 py-1 rounded-md" onClick={calculateDivision}>Divide</button>
        </div>
    )
}

export default CalculateSection;