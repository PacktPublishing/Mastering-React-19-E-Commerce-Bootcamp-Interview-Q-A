import React from "react";
import ComponentB from "./ComponentB";

const ComponentA = ({ str }) => {
    return (
        <section className="sectionA">
            <span>ComponentA</span>
            <ComponentB str={str} />
        </section>
    );
};

export default ComponentA;
