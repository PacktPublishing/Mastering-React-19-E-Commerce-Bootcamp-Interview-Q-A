import React from 'react'
import ComponentC from './ComponentC'
import AppContext from '../store/AppContext'

const ComponentB = () => {
    return (
        <AppContext.Consumer>
            {(str) => (
                <section className="sectionB">
                    <span>ComponentB</span>
                    <h3>{str}</h3>
                    <ComponentC />
                </section>
            )}
        </AppContext.Consumer>
    )
}

export default ComponentB