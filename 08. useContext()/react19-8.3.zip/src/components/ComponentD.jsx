import React from 'react'
import AppContext from '../store/AppContext'

const ComponentD = () => {
    return (
        <AppContext.Consumer>
            {(str) => (
                <section className='sectionD'>
                    <span>ComponentD</span>
                    <h2>{str}</h2>
                </section>
            )}
        </AppContext.Consumer>
    )
}

export default ComponentD