import React, { useContext } from 'react'
import ComponentC from './ComponentC'
import AppContext from '../store/AppContext'

const ComponentB = () => {
    const str = useContext(AppContext);
    return (
        <section className="sectionB">
            <span>ComponentB</span>
            <h3>{str}</h3>
            <ComponentC />
        </section>
    )
}

export default ComponentB