import React, { useContext } from 'react'
import AppContext from '../store/AppContext'

const ComponentD = () => {
    const str = useContext(AppContext);
    return (
        <section className='sectionD'>
            <span>ComponentD</span>
            <h2>{str}</h2>
        </section>
    )
}

export default ComponentD