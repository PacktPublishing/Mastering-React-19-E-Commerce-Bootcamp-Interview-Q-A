const InputSection = () => {
    return (
        <div className="border rounded-md p-5 h-[250px] w-[300px] space-y-3">
            <div className="grid gap-1">
                <label className="text-gray-700 font-medium">First Number:</label>
                <input type="number" placeholder="Enter First Number" className="border border-gray-200 rounded-md p-1" />
            </div>
            <div className="grid gap-1">
                <label className="text-gray-700 font-medium">Second Number:</label>
                <input type="number" placeholder="Enter Second Number" className="border border-gray-200 rounded-md p-1" />
            </div>
        </div>
    )
}

export default InputSection;