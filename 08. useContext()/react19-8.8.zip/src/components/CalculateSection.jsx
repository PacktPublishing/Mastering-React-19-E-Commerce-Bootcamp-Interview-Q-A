const CalculateSection = () => {
    return (
        <div className="border rounded-md p-5 h-[250px] w-[300px] grid gap-3">
            <button type="button" className="bg-blue-500 text-white px-3 py-1 rounded-md">Add</button>
            <button type="button" className="bg-blue-500 text-white px-3 py-1 rounded-md">Subtract</button>
            <button type="button" className="bg-blue-500 text-white px-3 py-1 rounded-md">Multiply</button>
            <button type="button" className="bg-blue-500 text-white px-3 py-1 rounded-md">Divide</button>
        </div>
    )
}

export default CalculateSection;