const ResultSection = () => {
    return (
        <div className="border rounded-md p-5 h-[250px] w-[300px]">
            <h1 className="text-3xl font-semibold">Answer: 12</h1>
        </div>
    )
}

export default ResultSection;