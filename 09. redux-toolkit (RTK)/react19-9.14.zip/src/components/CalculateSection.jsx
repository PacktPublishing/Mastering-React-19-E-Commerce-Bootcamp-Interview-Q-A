import { useContext } from "react";
import { CalculatorContext } from "../store/CalculatorContext";
import { calculateAddition, calculateSubtraction, calculateMultiplication, calculateDivision } from "../store/calculatorSlice";
import { useDispatch } from "react-redux";

const CalculateSection = () => {
    const dispatch = useDispatch();
    console.log("Calculate section is rendered!");

    return (
        <div className="border rounded-md p-5 h-[250px] w-[300px] grid gap-3">
            <button type="button" className="bg-blue-500 text-white px-3 py-1 rounded-md" onClick={() => dispatch(calculateAddition())}>Add</button>
            <button type="button" className="bg-blue-500 text-white px-3 py-1 rounded-md" onClick={() => dispatch(calculateSubtraction())}>Subtract</button>
            <button type="button" className="bg-blue-500 text-white px-3 py-1 rounded-md" onClick={() => dispatch(calculateMultiplication())}>Multiply</button>
            <button type="button" className="bg-blue-500 text-white px-3 py-1 rounded-md" onClick={() => dispatch(calculateDivision())}>Divide</button>
        </div>
    )
}

export default CalculateSection;