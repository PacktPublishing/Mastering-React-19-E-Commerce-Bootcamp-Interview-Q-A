import { useContext } from "react";
import { CalculatorContext } from "../store/CalculatorContext";
import { ThemeContext } from "../store/ThemeContext";
import { useDispatch, useSelector } from "react-redux";
import { handleInputChange } from "../store/calculatorSlice";

const InputSection = () => {
  const dispatch = useDispatch();
  const theme = useSelector((state) => state.theme);
  const { inputData } = useSelector((state) => state.calculator);

  const handleChange = (e) => {
    dispatch(handleInputChange({
      name: e.target.name,
      value: e.target.value,
    }))
  }
  console.log("Input section is rendered!");
  return (
    <div className="border rounded-md p-5 h-[250px] w-[300px] space-y-3">
      <div className="grid gap-1">
        <label className={`${theme === "light" ? "text-gray-700" : "text-white"} font-medium`}>First Number:</label>
        <input
          type="number"
          placeholder="Enter First Number"
          className="border border-gray-200 rounded-md p-1"
          name="num1"
          onChange={handleChange}
          value={inputData.num1}
        />
      </div>
      <div className="grid gap-1">
        <label className={`${theme === "light" ? "text-gray-700" : "text-white"} font-medium`}>Second Number:</label>
        <input
          type="number"
          placeholder="Enter Second Number"
          className="border border-gray-200 rounded-md p-1"
          name="num2"
          onChange={handleChange}
          value={inputData.num2}
        />
      </div>
    </div>
  );
};

export default InputSection;
