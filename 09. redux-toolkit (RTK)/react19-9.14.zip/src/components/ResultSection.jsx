import { useContext } from "react";
import { CalculatorContext } from "../store/CalculatorContext";
import { useSelector } from "react-redux";

const ResultSection = () => {
    const { result } = useSelector((state) => state.calculator);
    console.log("Result section is rendered!");

    return (
        <div className="border rounded-md p-5 h-[250px] w-[300px]">
            <h1 className="text-3xl font-semibold">Answer: {result}</h1>
        </div>
    )
}

export default ResultSection;