import { createContext, useState } from "react";

export const CalculatorContext = createContext();

const CalculatorContextProvider = ({ children }) => {
    const [inputData, setInputData] = useState({
        num1: "",
        num2: "",
    });
    const [result, setResult] = useState(0);

    const handleInputChange = (e) => {
        setInputData((prev) => ({ ...prev, [e.target.name]: parseFloat(e.target.value) }));
    }

    const calculateAddition = () => {
        const calculatedValue = inputData.num1 + inputData.num2;
        setResult(calculatedValue);
    }

    const calculateSubtraction = () => {
        const calculatedValue = inputData.num1 - inputData.num2;
        setResult(calculatedValue);
    }

    const calculateMultiplication = () => {
        const calculatedValue = inputData.num1 * inputData.num2;
        setResult(calculatedValue);
    }

    const calculateDivision = () => {
        const calculatedValue = inputData.num1 / inputData.num2;
        setResult(calculatedValue);
    }
    return (
        <CalculatorContext.Provider value={{
            inputData,
            result,
            handleInputChange,
            calculateAddition,
            calculateSubtraction,
            calculateMultiplication,
            calculateDivision
        }}>
            {children}
        </CalculatorContext.Provider>
    )
}
export default CalculatorContextProvider;