import { useSelector } from "react-redux";
import { Link, Outlet } from "react-router";

const Products = () => {
    const products = useSelector((state) => state.products);
    return (
        <>
            <div className="m-6 flex gap-4">
                {products.map((product) => (
                    <Link to={`/product-details/${product.id}`} key={product.id}>
                        <div
                            className="border border-gray-200 rounded-md shadow-md w-fit"
                        >
                            <img
                                src={product.image}
                                alt="apple"
                                className="h-[240px] w-[240px] object-cover rounded-t-md"
                            />
                            <div className="border-t border-gray-200 text-xl font-semibold p-2 text-center rounded-b-md">
                                <span>{product.name}</span>
                            </div>
                        </div>
                    </Link>
                ))}
            </div>
            <Outlet />
        </>
    );
}
export default Products;