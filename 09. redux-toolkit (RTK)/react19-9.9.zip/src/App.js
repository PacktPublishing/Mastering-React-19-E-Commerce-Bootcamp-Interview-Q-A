import React, { useContext } from "react";
import "./App.css";
import InputSection from "./components/InputSection";
import CalculateSection from "./components/CalculateSection";
import ResultSection from "./components/ResultSection";
import { ThemeContext } from "./store/ThemeContext";
import { useDispatch, useSelector } from "react-redux";
import { toggleTheme } from "./store/themeSlice";

function App() {
  const dispatch = useDispatch();
  const theme = useSelector((state) => state.theme);
  console.log(theme);
  return (
    <div className={theme === "dark" && "bg-black text-white h-screen"}>
      <button type="button" className="bg-blue-500 text-white px-3 py-1 rounded-md m-4" onClick={() => dispatch(toggleTheme())}>
        Switch to {theme === "light" ? "Dark" : "Light"} Theme
      </button>
      <div className="grid grid-cols-3 gap-6 p-5">
        <InputSection />
        <CalculateSection />
        <ResultSection />
      </div>
    </div>
  );
}

export default App;
