import { useEffect, useState } from "react";
import "./App.css";

function App() {
  const [users, setUsers] = useState([]);

  const deleteUser = async () => {
    try {
      const response = await fetch("https://dummyjson.com/users/0", {
        method: "DELETE",
      })
      const data = await response.json();
      if (response.ok) {
        console.log(data);
      } else {
        throw new Error(data.message);
      }
    } catch (error) {
      alert(error);
    }
  }

  useEffect(() => {
    fetch("https://dummyjson.com/users")
      .then((response) => response.json())
      .then((data) => setUsers(data.users));

    deleteUser();
  }, []);

  const handleAddUser = () => {
    fetch("https://dummyjson.com/users/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        firstName: "John",
        lastName: "Doe",
      }),
    }).then((response) => response.json())
      .then((data) => console.log(data));
  }

  return (
    <div className="max-w-[600px] mx-auto space-y-2 my-5">
      <button className="border px-3 py-1 text-xs" onClick={handleAddUser}>
        Add User
      </button>
      {users.map((user) => (
        <div className="p-2 border border-gray-100 rounded-md" key={user.id}>
          <span>{user.id} - {user.firstName} {user.lastName}</span>
        </div>
      ))}
    </div>
  );
}

export default App;