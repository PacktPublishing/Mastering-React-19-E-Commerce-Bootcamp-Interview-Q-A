import "./App.css";

function App() {
  fetch("https://dummyjson.com/users")
    .then((response) => response.json())
    .then((data) => console.log(data));

  return (
    <div></div>
  );
}

export default App;