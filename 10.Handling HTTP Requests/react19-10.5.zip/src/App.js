import { useEffect, useState } from "react";
import "./App.css";

function App() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetch("https://dummyjson.com/users")
      .then((response) => response.json())
      .then((data) => setUsers(data.users));
  }, []);

  console.log(users);

  return (
    <div className="max-w-[600px] mx-auto space-y-2 my-5">
      {users.map((user) => (
        <div className="p-2 border border-gray-100 rounded-md" key={user.id}>
          <span>{user.id} - {user.firstName} {user.lastName}</span>
        </div>
      ))}
    </div>
  );
}

export default App;