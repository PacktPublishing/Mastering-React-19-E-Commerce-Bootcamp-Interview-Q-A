import { useEffect, useState } from "react";
import "./App.css";

function App() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetch("https://dummyjson.com/users")
      .then((response) => response.json())
      .then((data) => setUsers(data.users));

    fetch("https://dummyjson.com/users/2", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        firstName: "John",
        lastName: "Doe",
      }),
    }).then((response) => response.json())
      .then((data) => console.log(data));
  }, []);

  const handleAddUser = () => {
    fetch("https://dummyjson.com/users/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        firstName: "John",
        lastName: "Doe",
      }),
    }).then((response) => response.json())
      .then((data) => console.log(data));
  }

  return (
    <div className="max-w-[600px] mx-auto space-y-2 my-5">
      <button className="border px-3 py-1 text-xs" onClick={handleAddUser}>
        Add User
      </button>
      {users.map((user) => (
        <div className="p-2 border border-gray-100 rounded-md" key={user.id}>
          <span>{user.id} - {user.firstName} {user.lastName}</span>
        </div>
      ))}
    </div>
  );
}

export default App;