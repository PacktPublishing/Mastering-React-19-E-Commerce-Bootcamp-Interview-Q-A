const express = require("express");
const app = express();
require("dotenv").config();

const PORT = process.env.PORT_NUMBER;

app.listen(PORT, () => {
    console.log("Server is running on the port - ", PORT);
})