const express = require("express");
const app = express();
require("dotenv").config();

app.get("/", (req, res) => {
    let data = {
        firstName: "John",
        lastName: "Doe",
        age: 30,
    }
    res.status(200).send(data);
})

const PORT = process.env.PORT_NUMBER;

app.listen(PORT, () => {
    console.log("Server is running on the port - ", PORT);
})