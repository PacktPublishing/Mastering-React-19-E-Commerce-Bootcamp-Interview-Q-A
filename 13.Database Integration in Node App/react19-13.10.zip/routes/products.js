const express = require("express");
const router = express.Router();
const mysql = require("mysql2");

const pool = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "init@mysql",
    database: "local_db",
    port: "3306",
    multipleStatements: true,
})

router.get("/", (req, res) => {
    pool.query("SELECT * FROM products", (err, rows) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.status(200).send(rows);
    })
});

router.post("/add", (req, res) => {
    const { name, image, price, description } = req.body;
    pool.query("INSERT INTO products (name, image, price, description) VALUES (?, ?, ?, ?)", [name, image, price, description], (err, rows) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.status(201).send(rows);
    })
});

router.get("/:id", (req, res) => {
    const { id } = req.params;
    pool.query("SELECT * FROM products WHERE id = ?", [id], (err, rows) => {
        if (err) {
            return res.status(500).send(err);
        }
        if (rows.length === 0) {
            return res.status(404).send("Product not found.")
        }
        res.status(200).send(rows);
    })
});

router.put("/update/:id", (req, res) => {
    const { id } = req.params;
    const { name, image, price, description } = req.body;
    pool.query("UPDATE products SET name = ?, image = ?, price = ?, description = ? WHERE id = ?", [name, image, price, description, id], (err, rows) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.status(200).send(rows);
    })
});

router.delete("/:id", (req, res) => {
    const { id } = req.params;
    pool.query("DELETE FROM products WHERE id = ?", [id], (err, rows) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.status(200).send(rows);
    })
})

module.exports = router;