const express = require("express");
const app = express();
require("dotenv").config();
const mysql = require("mysql2");

const pool = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "init@mysql",
    database: "local_db",
    port: "3306",
    multipleStatements: true,
})

app.get("/", (req, res) => {
    pool.query("SELECT * FROM products", (err, rows) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.status(200).send(rows);
    })
})

const PORT = process.env.PORT_NUMBER;

app.listen(PORT, () => {
    console.log("Server is running on the port - ", PORT);
})