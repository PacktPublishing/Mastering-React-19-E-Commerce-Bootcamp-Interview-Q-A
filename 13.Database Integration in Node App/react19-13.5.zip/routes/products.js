const express = require("express");
const router = express.Router();
const mysql = require("mysql2");

const pool = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "init@mysql",
    database: "local_db",
    port: "3306",
    multipleStatements: true,
})

router.get("/", (req, res) => {
    pool.query("SELECT * FROM products", (err, rows) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.status(200).send(rows);
    })
})

module.exports = router;