const express = require("express");
const app = express();
require("dotenv").config();
const products = require("./routes/products");

app.use(express.json());
app.use("/products", products);

const PORT = process.env.PORT_NUMBER;

app.listen(PORT, () => {
    console.log("Server is running on the port - ", PORT);
})