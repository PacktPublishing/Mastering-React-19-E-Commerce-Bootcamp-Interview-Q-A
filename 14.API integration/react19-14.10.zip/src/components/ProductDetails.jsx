import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Link, useLocation, useNavigate, useOutletContext, useParams } from "react-router";
import DeleteConfirmationModal from "./DeleteConfirmationModal";

const ProductDetails = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [selectedProduct, setSelectedProduct] = useState({});
    const [isOpen, setIsOpen] = useState(false);

    useEffect(() => {
        fetch(`${process.env.REACT_APP_API_BASE_URL}/products/${id}`)
            .then((response) => {
                const data = response.json();
                if (response.ok) {
                    return data;
                } else {
                    throw new Error(data);
                }
            })
            .then((data) => setSelectedProduct(data))
            .catch((error) => console.log(error));
    }, []);

    const handleDeleteProduct = () => {
        fetch(`${process.env.REACT_APP_API_BASE_URL}/products/${id}`, {
            method: "DELETE",
        })
            .then((response) => {
                const data = response.json();
                if (response.ok) {
                    return data;
                } else {
                    throw new Error(data);
                }
            })
            .then((data) => {
                alert(data.message);
                navigate("/");
            })
            .catch((error) => console.log(error));
    }
    const handleModalOpen = () => {
        setIsOpen(true);
    }

    const handleModalClose = () => {
        setIsOpen(false);
    }
    return (
        <>
            <div className="mx-6 max-w-[800px] mx-auto">
                <div className="border border-neutral-50 rounded-md shadow-md bg-neutral-50 grid grid-cols-3 mt-10">
                    <img
                        src={selectedProduct.image}
                        alt={selectedProduct.name}
                        className="h-[260px] w-[260px] col-span-1 object-cover rounded-l-md"
                    />
                    <div className="flex flex-col gap-2 col-span-2 my-auto px-5">
                        <span className="text-3xl font-semibold">
                            {selectedProduct.name}
                        </span>
                        <span className="text-2xl font-medium">
                            ${selectedProduct.price}
                        </span>
                        <span className="text-md leading-5 text-neutral-500">
                            {selectedProduct.description}
                        </span>
                        <div className="flex gap-2 my-2">
                            <Link
                                to={`/products/edit/${id}`}
                                className="border px-3 py-1 rounded-md"
                            >
                                Edit Product
                            </Link>
                            <button
                                className="bg-red-500 text-white px-3 py-1 rounded-md"
                                onClick={handleModalOpen}
                            >
                                Delete Product
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            {isOpen && (
                <DeleteConfirmationModal
                    handleModalClose={handleModalClose}
                    handleDeleteProduct={handleDeleteProduct}
                />
            )}
        </>
    );
}

export default ProductDetails;