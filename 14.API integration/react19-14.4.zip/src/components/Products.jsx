import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, Outlet } from "react-router";
import { setProducts } from "../store/productSlice";

const Products = () => {
    const dispatch = useDispatch();
    const products = useSelector((state) => state.products);

    useEffect(() => {
        fetch(`${process.env.REACT_APP_API_BASE_URL}/products`)
            .then((response) => {
                const data = response.json();
                if (response.ok) {
                    return data;
                } else {
                    throw new Error(data);
                }
            })
            .then((data) => dispatch(setProducts(data)))
            .catch((error) => console.log(error));
    }, [])
    return (
        <>
            <div className="m-6 flex gap-4">
                {products.length > 0 ?
                    products.map((product) => (
                        <Link to={`/product-details/${product.id}`} key={product.id}>
                            <div
                                className="border border-gray-200 rounded-md shadow-md w-fit"
                            >
                                <img
                                    src={product.image}
                                    alt="apple"
                                    className="h-[240px] w-[240px] object-cover rounded-t-md"
                                />
                                <div className="border-t border-gray-200 text-xl font-semibold p-2 text-center rounded-b-md">
                                    <span>{product.name}</span>
                                </div>
                            </div>
                        </Link>
                    )) : (
                        <h1 className="text-2xl font-semibold mx-auto">No Products Available.</h1>
                    )}
            </div>
            <Outlet />
        </>
    );
}
export default Products;