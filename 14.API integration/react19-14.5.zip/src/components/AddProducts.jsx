const AddProducts = () => {
    return (
        <div className="border border-gray-50 shadow-lg rounded-md p-10 max-w-[1024px] m-6 mx-auto">
            <h1 className="text-3xl font-semibold">Add Product</h1>
        </div>
    )
}

export default AddProducts