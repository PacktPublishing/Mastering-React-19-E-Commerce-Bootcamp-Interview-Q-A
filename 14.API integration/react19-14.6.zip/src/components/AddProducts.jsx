import { useState } from "react";

const AddProducts = () => {
    const [data, setData] = useState({
        name: "",
        image: "",
        price: "",
        description: ""
    });

    const handleChange = (e) => {
        setData({ ...data, [e.target.name]: e.target.value });
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(data);
    }
    return (
        <div className="border border-gray-50 shadow-lg rounded-md p-10 max-w-[1024px] m-6 mx-auto">
            <h1 className="text-3xl font-semibold">Add Product</h1>
            <form className="grid grid-cols-2 gap-4 my-8" onSubmit={handleSubmit}>
                <div className="flex flex-col gap-2">
                    <label className="font-semibold">Product Name:</label>
                    <input
                        type="text"
                        name="name"
                        className="border border-gray-200 rounded-md p-2"
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="flex flex-col gap-2">
                    <label className="font-semibold">Image URL:</label>
                    <input
                        type="text"
                        name="image"
                        className="border border-gray-200 rounded-md p-2"
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="flex flex-col gap-2">
                    <label className="font-semibold">Price:</label>
                    <input
                        type="number"
                        name="price"
                        className="border border-gray-200 rounded-md p-2"
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="flex flex-col gap-2">
                    <label className="font-semibold">Description:</label>
                    <textarea
                        type="text"
                        name="description"
                        className="border border-gray-200 rounded-md p-2"
                        rows={4}
                        onChange={handleChange}
                        required
                    />
                </div>
                <button type="submit" className="bg-blue-500 text-white px-3 py-1 rounded-md col-span-2 w-[400px] mx-auto my-4">
                    Submit
                </button>
            </form>
        </div>
    )
}

export default AddProducts