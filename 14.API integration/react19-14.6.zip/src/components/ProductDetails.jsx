import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useLocation, useOutletContext, useParams } from "react-router";

const ProductDetails = () => {
    const { id } = useParams();
    const [selectedProduct, setSelectedProduct] = useState();

    useEffect(() => {
        fetch(`${process.env.REACT_APP_API_BASE_URL}/products/${id}`)
            .then((response) => {
                const data = response.json();
                if (response.ok) {
                    return data;
                } else {
                    throw new Error(data);
                }
            })
            .then((data) => setSelectedProduct(data))
            .catch((error) => console.log(error));
    }, [])
    return (
        <div className="mx-6 max-w-[800px] mx-auto">
            <div className="border border-neutral-50 rounded-md shadow-md bg-neutral-200 grid grid-cols-3 mt-10">
                <img src={selectedProduct.image} alt={selectedProduct.name} className="h-[260px] w-[260px] col-span-1 object-cover rounded-l-md" />
                <div className="flex flex-col gap-2 col-span-2 my-auto px-5">
                    <span className="text-3xl font-semibold">{selectedProduct.name}</span>
                    <span className="text-2xl font-medium">${selectedProduct.price}</span>
                    <span className="text-md leading-5 text-neutral-500">{selectedProduct.description}</span>
                </div>
            </div>
        </div>
    )
}

export default ProductDetails;