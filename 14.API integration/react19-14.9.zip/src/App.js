import './App.css';
import Home from './components/Home';
import Products from './components/Products';
import About from './components/About';
import { Link, Navigate, Route, Routes } from 'react-router';
import NotFound from './components/NotFound';
import ProductDetails from './components/ProductDetails';
import Layout from './components/Layout';
import AddEditProducts from './components/AddEditProducts';

function App() {
  return (
    <div>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Products />} />
          <Route path="/product-details/:id" element={<ProductDetails />} />
          <Route path="/about" element={<About />} />
          <Route path="/products">
            <Route path="add" element={<AddEditProducts />} />
            <Route path="edit/:id" element={<AddEditProducts />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;
