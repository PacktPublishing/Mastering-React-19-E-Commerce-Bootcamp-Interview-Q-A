import { useState } from "react";

const useCounter = (initialValue, incrementValue) => {
    const [counter, setCounter] = useState(initialValue);

    const incrementCounter = () => {
        setCounter(counter + incrementValue);
    }

    return { counter, incrementCounter };

}

export default useCounter;