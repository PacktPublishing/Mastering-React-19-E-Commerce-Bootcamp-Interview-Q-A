import React, { useState } from 'react'
import useCounter from '../hooks/useCounter'
import useTimer from '../hooks/useTimer';

const Component2 = () => {
    const timer = useTimer(2);
    return (
        <div className='card'>
            <h1>Component2</h1>
            <h2>{timer}</h2>
        </div>
    )
}

export default Component2