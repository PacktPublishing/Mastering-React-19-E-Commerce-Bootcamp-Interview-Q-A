import React, { useState } from 'react'
import useCounter from '../hooks/useCounter'
import useTimer from '../hooks/useTimer';

const Component3 = () => {
    const timer = useTimer(5);
    return (
        <div className='card'>
            <h1>Component3</h1>
            <h2>{timer}</h2>
        </div>
    )
}

export default Component3