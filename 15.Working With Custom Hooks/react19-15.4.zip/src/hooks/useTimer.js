import { useEffect, useState } from "react";

const useTimer = (incrementValue) => {
    const [time, setTime] = useState(0);

    useEffect(() => {
        const timer = setInterval(() => {
            setTime((prev) => prev + incrementValue);
        }, 1000);

        return () => clearInterval(timer);
    }, []);

    return time;
}

export default useTimer;