const About = () => {
    return (
        <div>About Component</div>
    )
}
export default About;