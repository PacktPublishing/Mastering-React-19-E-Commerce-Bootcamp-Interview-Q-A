import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router";
import useFetchProductDetails from "../hooks/useFetchProductDetails";

const AddEditProducts = () => {
    const navigate = useNavigate();
    const { id } = useParams();
    const [data, setData] = useState({
        name: "",
        image: "",
        price: "",
        description: ""
    });

    useFetchProductDetails(id, (product) => setData(product));

    const handleChange = (e) => {
        setData({ ...data, [e.target.name]: e.target.value });
    };

    const handleAddProduct = () => {
        fetch(`${process.env.REACT_APP_API_BASE_URL}/products/add`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data),
        }).then((response) => {
            const data = response.json();
            if (response.ok) {
                return data;
            } else {
                throw new Error(data);
            }
        }).then((data) => {
            alert(data.message);
            navigate("/");
        }).catch((error) => console.log(error));
    }

    const handleEditProduct = () => {
        fetch(`${process.env.REACT_APP_API_BASE_URL}/products/update/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data),
        }).then((response) => {
            const data = response.json();
            if (response.ok) {
                return data;
            } else {
                throw new Error(data);
            }
        }).then((data) => {
            alert(data.message);
            navigate(`/product-details/${id}`);
        }).catch((error) => console.log(error));
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        if (id) {
            handleEditProduct();
        } else {
            handleAddProduct();
        }
    }
    return (
        <div className="border border-gray-50 shadow-lg rounded-md p-10 max-w-[1024px] m-6 mx-auto">
            <h1 className="text-3xl font-semibold">
                {id ? "Edit Product" : "Add Product"}
            </h1>
            <form className="grid grid-cols-2 gap-4 my-8" onSubmit={handleSubmit}>
                <div className="flex flex-col gap-2">
                    <label className="font-semibold">Product Name:</label>
                    <input
                        type="text"
                        name="name"
                        className="border border-gray-200 rounded-md p-2"
                        onChange={handleChange}
                        value={data.name}
                        required
                    />
                </div>
                <div className="flex flex-col gap-2">
                    <label className="font-semibold">Image URL:</label>
                    <input
                        type="text"
                        name="image"
                        className="border border-gray-200 rounded-md p-2"
                        onChange={handleChange}
                        value={data.image}
                        required
                    />
                </div>
                <div className="flex flex-col gap-2">
                    <label className="font-semibold">Price:</label>
                    <input
                        type="number"
                        name="price"
                        className="border border-gray-200 rounded-md p-2"
                        onChange={handleChange}
                        value={data.price}
                        required
                    />
                </div>
                <div className="flex flex-col gap-2">
                    <label className="font-semibold">Description:</label>
                    <textarea
                        type="text"
                        name="description"
                        className="border border-gray-200 rounded-md p-2"
                        rows={4}
                        onChange={handleChange}
                        value={data.description}
                        required
                    />
                </div>
                <button type="submit" className="bg-blue-500 text-white px-3 py-1 rounded-md col-span-2 w-[400px] mx-auto my-4">
                    Submit
                </button>
            </form>
        </div>
    );
};

export default AddEditProducts;