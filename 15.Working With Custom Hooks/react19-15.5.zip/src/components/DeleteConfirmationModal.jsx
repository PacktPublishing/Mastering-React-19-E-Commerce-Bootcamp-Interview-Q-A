const DeleteConfirmationModal = ({ handleModalClose, handleDeleteProduct }) => {
    return (
        <div className="fixed inset-0 flex justify-center items-center z-50">
            <div className="fixed inset-0 bg-black opacity-50" />
            <div className="relative w-full max-w-xl bg-white rounded-lg p-10 shadow-lg text-xl">
                <button
                    type="button"
                    className="absolute top-2 right-5 text-3xl p-0 text-gray-400"
                    onClick={handleModalClose}
                >
                    &times;
                </button>
                <div className="flex flex-col">
                    <p className="font-semibold text-center">
                        Are you sure you want to delete this product?
                    </p>
                    <div className="flex gap-4 mt-4 self-center">
                        <button className="bg-red-500 text-white px-3 py-1 rounded-md" onClick={handleDeleteProduct}>
                            Delete
                        </button>
                        <button className="border px-3 py-1 rounded-md" onClick={handleModalClose}>
                            Cancel
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default DeleteConfirmationModal;