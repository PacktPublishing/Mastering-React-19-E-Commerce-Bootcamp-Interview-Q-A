import { useEffect, useState } from "react";
import TodoForm from "./components/TodoForm";
import TodoList from "./components/TodoList";
import TodoHeader from "./components/TodoHeader";

function App() {
  const [todos, setTodos] = useState(() => {
    const savedTodos = localStorage.getItem("todos");
    return savedTodos ? JSON.parse(savedTodos) : [];
  });

  useEffect(() => {
    localStorage.setItem("todos", JSON.stringify(todos));
  }, [todos]);

  const addTodo = (text) => {
    if (!text.trim()) return; // Prevent adding empty tasks
    const todo = { id: Date.now(), text, completed: false };
    setTodos([...todos, todo]);
  };

  const toggleTaskStatus = (id) => {
    setTodos(
      todos.map((todo) =>
        todo.id === id ? { ...todo, completed: !todo.completed } : todo
      )
    );
  };

  const deleteTodo = (id) => {
    setTodos(todos.filter((todo) => todo.id !== id));
  };

  return (
    <div className="flex items-center justify-center p-6 bg-gradient-to-br from-indigo-500 to-purple-600 min-h-screen">
      <div className="bg-white w-full max-w-xl rounded-lg shadow-lg overflow-hidden">
        <TodoHeader todos={todos} />
        <TodoForm onAdd={addTodo} />
        <TodoList todos={todos} onToggle={toggleTaskStatus} onDelete={deleteTodo} />
      </div>
    </div>
  );
}

export default App;
