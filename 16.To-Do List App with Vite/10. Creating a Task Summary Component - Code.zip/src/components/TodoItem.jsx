import React from "react";
import { CheckCircle, Circle, Trash2 } from "lucide-react";

const TodoItem = ({ todo, onToggle, onDelete }) => {
  return (
    <li
      className={`p-4 flex items-center justify-between transition-colors ${
        todo.completed ? "bg-gray-50" : ""
      }`}
    >
      <div className="flex items-center">
        <button
          onClick={() => onToggle(todo.id)}
          className="mr-2 text-indigo-600 hover:text-indigo-800 transition-colors"
        >
          {todo.completed ? (
            <CheckCircle size={20} className="text-green-500" />
          ) : (
            <Circle size={20} />
          )}
        </button>
        <span
          className={`${
            todo.completed ? "line-through text-gray-500" : "text-gray-800"
          }`}
        >
          {todo.text}
        </span>
      </div>
      <button
        onClick={() => onDelete(todo.id)}
        className="text-red-500 hover:text-red-700 transition-colors"
      >
        <Trash2 size={18} />
      </button>
    </li>
  );
};

export default TodoItem;
