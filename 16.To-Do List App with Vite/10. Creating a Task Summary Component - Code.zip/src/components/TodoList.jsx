import React from "react";
import TodoItem from "./TodoItem";

const TodoList = ({ todos, onToggle, onDelete }) => {
  return (
    <ul className="divide-y overflow-y-auto max-h-96">
      {todos.length === 0 ? (
        <li className="p-4 text-center text-gray-500">
          No tasks yet. Add one above!
        </li>
      ) : (
        todos.map((todo) => (
          <TodoItem
            key={todo.id}
            todo={todo}
            onToggle={onToggle}
            onDelete={onDelete}
          />
        ))
      )}
    </ul>
  );
};

export default TodoList;
