import { useState } from "react";

const TodoForm = ({ onAdd }) => {
  const [newTodo, setNewTodo] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (newTodo.trim() === "") return;

    onAdd(newTodo);
    setNewTodo("");
  };

  return (
    <form className="p-4 border-b">
      <div>
        <input
          type="text"
          onChange={(e) => setNewTodo(e.target.value)}
          className="flex-grow p-2 border rounded-l-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
          placeholder="Add a new task"
        />
        <button
          type="submit"
          className="bg-indigo-600 text-white p-2 rounded-r-md hover:bg-indigo-700 transition-colors flex items-center"
        >
          Add
        </button>
      </div>
    </form>
  );
};
export default TodoForm;
