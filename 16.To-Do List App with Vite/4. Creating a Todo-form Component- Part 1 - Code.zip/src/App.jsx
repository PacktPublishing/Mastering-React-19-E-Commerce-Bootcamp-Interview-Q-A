import TodoForm from "./components/TodoForm";

function App() {
  return (
    <div>
      <TodoForm></TodoForm>
    </div>
  );
}

export default App;
