import { useState } from "react";
import TodoForm from "./components/TodoForm";
import TodoList from "./components/TodoList";

function App() {
  const [todos, setTodos] = useState([]);

  const addTodo = (text) => {
    const todo = {
      id: Date.now(),
      text,
    };
    setTodos([...todos, todo]);
  };

  return (
    <div>
      <TodoForm onAdd={addTodo}></TodoForm>
      <TodoList todos={todos}></TodoList>
    </div>
  );
}

export default App;
