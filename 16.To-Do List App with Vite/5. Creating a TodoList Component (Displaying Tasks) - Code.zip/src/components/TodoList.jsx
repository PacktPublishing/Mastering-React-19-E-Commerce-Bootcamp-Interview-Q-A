const TodoList = ({ todos }) => {
  return (
    <ul className="max-h-96 overflow-y-auto divide-y">
      {todos.length === 0 ? (
        <li className="text-center text-gray-500">
          No tasks yet. Add one above!
        </li>
      ) : (
        todos.map((todo) => (
          <li key={todo.id} className="p-2">
            <div className="flex items-center">
              <span>{todo.text}</span>
            </div>
          </li>
        ))
      )}
    </ul>
  );
};
export default TodoList;
