const TodoItem = ({ todo, onToggle }) => {
  return (
    <li
      className={`p-4 flex items-center justify-between transition-colors ${
        todo.completed ? "bg-green-200" : ""
      }`}
    >
      <div className="flex items-center">
        <button
          onClick={() => onToggle(todo.id)}
        >{`Mark as completed -->`}</button>
        <span>{todo.text}</span>
      </div>
    </li>
  );
};
export default TodoItem;
