import TodoItem from "./TodoItem";

const TodoList = ({ todos, onToggle }) => {
  return (
    <ul className="max-h-96 overflow-y-auto divide-y">
      {todos.length === 0 ? (
        <li className="text-center text-gray-500">
          No tasks yet. Add one above!
        </li>
      ) : (
        todos.map((todo) => (
          <TodoItem key={todo.id} todo={todo} onToggle={onToggle}></TodoItem>
        ))
      )}
    </ul>
  );
};
export default TodoList;
