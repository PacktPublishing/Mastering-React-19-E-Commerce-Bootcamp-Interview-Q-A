const TodoItem = ({ todo, onToggle, onDelete }) => {
  return (
    <li
      className={`p-4 flex items-center justify-between transition-colors ${
        todo.completed ? "bg-green-200" : ""
      }`}
    >
      <div className="flex items-center">
        <button
          onClick={() => onToggle(todo.id)}
        >{`Mark as completed -->`}</button>
        <span>{todo.text}</span>
      </div>
      <button
        className="px-3 py-1 bg-red-500 text-white rounded"
        onClick={() => onDelete(todo.id)}
      >
        {`Delete`}
      </button>
    </li>
  );
};
export default TodoItem;
