import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Guide from './pages/Guide';
import { BookOpen } from 'lucide-react';

function App() {
  // State for todos
  const [todos, setTodos] = useState(() => {
    // Load todos from localStorage on initial render
    const savedTodos = localStorage.getItem('todos');
    return savedTodos ? JSON.parse(savedTodos) : [];
  });

  // Save todos to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('todos', JSON.stringify(todos));
  }, [todos]);

  // Add a new todo
  const addTodo = (text) => {
    const todo = {
      id: Date.now(),
      text,
      completed: false
    };
    
    setTodos([...todos, todo]);
  };

  // Toggle todo completion status
  const toggleTodo = (id) => {
    setTodos(
      todos.map(todo => 
        todo.id === id ? { ...todo, completed: !todo.completed } : todo
      )
    );
  };

  // Delete a todo
  const deleteTodo = (id) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  return (
    <BrowserRouter>
      <div className="relative bg-red-50">
        <Routes>
          <Route 
            path="/" 
            element={
              <Home 
                todos={todos} 
                addTodo={addTodo} 
                toggleTodo={toggleTodo} 
                deleteTodo={deleteTodo} 
              />
            } 
          />
          <Route path="/guide" element={<Guide />} />
        </Routes>
        
        {/* Guide Button */}
        <Link 
          to="/guide" 
          className="fixed bottom-4 left-4 bg-indigo-600 text-white p-3 rounded-full shadow-lg hover:bg-indigo-700 transition-colors"
          aria-label="View Step-by-Step Guide"
        >
          <BookOpen size={24} />
        </Link>
      </div>
    </BrowserRouter>
  );
}

export default App;