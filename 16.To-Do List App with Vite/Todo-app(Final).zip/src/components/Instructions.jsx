import React, { useState } from 'react';
import { HelpCircle, X, ChevronRight, ChevronDown } from 'lucide-react';

const Instructions = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState(null);

  const toggleSection = (index) => {
    setActiveSection(activeSection === index ? null : index);
  };

  const sections = [
    {
      title: "Getting Started",
      content: "Welcome to the Todo App! This application helps you keep track of your tasks. Add new tasks, mark them as complete, and delete them when you're done."
    },
    {
      title: "Adding Tasks",
      content: "To add a new task, type your task in the input field at the top of the app and click the 'Add' button or press Enter. Your task will appear in the list below."
    },
    {
      title: "Completing Tasks",
      content: "To mark a task as complete, click the circle icon next to the task. The task will be crossed out and the circle will turn into a green checkmark. Click again to mark it as incomplete."
    },
    {
      title: "Deleting Tasks",
      content: "To delete a task, click the trash icon on the right side of the task. Be careful, as this action cannot be undone!"
    },
    {
      title: "Task Statistics",
      content: "At the top of the app, you can see statistics about your tasks: the total number of tasks, how many are completed, and how many are still pending."
    },
    {
      title: "Data Storage",
      content: "Your tasks are saved in your browser's local storage. This means they will persist even if you close the browser or refresh the page, but they won't sync across different devices."
    },
    {
      title: "App Architecture",
      content: "This app is built with React and uses a component-based architecture. The main components are TodoHeader, TodoForm, TodoList, and TodoItem. Each component has a specific responsibility, making the code more maintainable and easier to understand."
    }
  ];

  if (!isOpen) {
    return (
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 bg-indigo-600 text-white p-3 rounded-full shadow-lg hover:bg-indigo-700 transition-colors"
        aria-label="Open Instructions"
      >
        <HelpCircle size={24} />
      </button>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
        <div className="bg-indigo-600 p-4 flex justify-between items-center">
          <h2 className="text-xl font-bold text-white">Todo App Instructions</h2>
          <button 
            onClick={() => setIsOpen(false)}
            className="text-white hover:text-indigo-200 transition-colors"
            aria-label="Close Instructions"
          >
            <X size={24} />
          </button>
        </div>
        
        <div className="overflow-y-auto p-4 flex-grow">
          {sections.map((section, index) => (
            <div key={index} className="mb-4 border rounded-lg overflow-hidden">
              <button 
                onClick={() => toggleSection(index)}
                className="w-full p-4 text-left bg-gray-50 hover:bg-gray-100 transition-colors flex justify-between items-center"
              >
                <span className="font-medium">{section.title}</span>
                {activeSection === index ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
              </button>
              {activeSection === index && (
                <div className="p-4 bg-white">
                  <p>{section.content}</p>
                </div>
              )}
            </div>
          ))}
        </div>
        
        <div className="bg-gray-50 p-4 text-center">
          <button 
            onClick={() => setIsOpen(false)}
            className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors"
          >
            Close Instructions
          </button>
        </div>
      </div>
    </div>
  );
};

export default Instructions;