import React from 'react';
import { Code, FileCode, Layers, Database, Palette, Zap, GitBranch } from 'lucide-react';

const StepByStep = () => {
  const steps = [
    {
      icon: <FileCode size={24} />,
      title: "Project Setup",
      description: "Create a new Vite project with React. Install TailwindCSS for styling and Lucide React for icons.",
      code: "npm create vite@latest todo-app -- --template react\ncd todo-app\nnpm install\nnpm install tailwindcss postcss autoprefixer lucide-react\nnpx tailwindcss init -p"
    },
    {
      icon: <Layers size={24} />,
      title: "Component Structure",
      description: "Organize the app into reusable components: TodoHeader, TodoForm, TodoList, and TodoItem.",
      code: "src/\n├── components/\n│   ├── TodoHeader.jsx\n│   ├── TodoForm.jsx\n│   ├── TodoList.jsx\n│   └── TodoItem.jsx\n├── types/\n│   └── index.js\n└── App.jsx"
    },
    {
      icon: <Database size={24} />,
      title: "State Management",
      description: "Use React's useState hook to manage todos. Implement localStorage for data persistence.",
      code: "const [todos, setTodos] = useState(() => {\n  const savedTodos = localStorage.getItem('todos');\n  return savedTodos ? JSON.parse(savedTodos) : [];\n});\n\nuseEffect(() => {\n  localStorage.setItem('todos', JSON.stringify(todos));\n}, [todos]);"
    },
    {
      icon: <Code size={24} />,
      title: "Todo Operations",
      description: "Implement functions to add, toggle, and delete todos.",
      code: "// Add a todo\nconst addTodo = (text) => {\n  const todo = { id: Date.now(), text, completed: false };\n  setTodos([...todos, todo]);\n};\n\n// Toggle a todo\nconst toggleTodo = (id) => {\n  setTodos(todos.map(todo => \n    todo.id === id ? { ...todo, completed: !todo.completed } : todo\n  ));\n};\n\n// Delete a todo\nconst deleteTodo = (id) => {\n  setTodos(todos.filter(todo => todo.id !== id));\n};"
    },
    {
      icon: <Palette size={24} />,
      title: "Styling with Tailwind",
      description: "Use TailwindCSS utility classes for responsive and beautiful UI.",
      code: "// Example of Tailwind styling\n<div className=\"min-h-screen bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center p-4\">\n  <div className=\"bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden\">\n    {/* Components */}\n  </div>\n</div>"
    },
    {
      icon: <Zap size={24} />,
      title: "User Experience",
      description: "Add visual feedback for completed tasks and interactive elements.",
      code: "// Conditional styling for completed todos\n<span className={`${todo.completed ? 'line-through text-gray-500' : 'text-gray-800'}`}>\n  {todo.text}\n</span>"
    },
    {
      icon: <GitBranch size={24} />,
      title: "Future Enhancements",
      description: "Potential improvements: categories, due dates, search, filters, and cloud sync.",
      code: "// Example of adding a category field\nconst TodoType = {\n  id: 0,\n  text: '',\n  completed: false,\n  category: '',\n  dueDate: null\n};"
    }
  ];

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-xl shadow-xl">
      <h1 className="text-3xl font-bold text-center mb-8 text-indigo-600">Building a Todo App: Step by Step</h1>
      
      <div className="space-y-8">
        {steps.map((step, index) => (
          <div key={index} className="border rounded-lg overflow-hidden">
            <div className="bg-indigo-50 p-4 flex items-center gap-3">
              <div className="bg-indigo-600 text-white p-2 rounded-lg">
                {step.icon}
              </div>
              <h2 className="text-xl font-semibold text-indigo-800">
                Step {index + 1}: {step.title}
              </h2>
            </div>
            
            <div className="p-4">
              <p className="mb-4 text-gray-700">{step.description}</p>
              
              <div className="bg-gray-800 text-gray-200 p-4 rounded-md overflow-x-auto">
                <pre className="font-mono text-sm whitespace-pre-wrap">{step.code}</pre>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-8 p-4 bg-indigo-50 rounded-lg">
        <h3 className="text-lg font-semibold text-indigo-800 mb-2">Conclusion</h3>
        <p className="text-gray-700">
          This Todo app demonstrates fundamental React concepts: component composition, state management, 
          and effects. By breaking down the UI into reusable components and implementing core functionality 
          step by step, we've created a maintainable and user-friendly application.
        </p>
      </div>
    </div>
  );
};

export default StepByStep;