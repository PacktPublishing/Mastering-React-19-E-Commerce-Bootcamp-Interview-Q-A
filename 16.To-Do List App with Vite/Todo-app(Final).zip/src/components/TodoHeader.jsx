import React from 'react';

const TodoHeader = ({ todos }) => {
  const totalTodos = todos.length;
  const completedTodos = todos.filter(todo => todo.completed).length;
  const pendingTodos = totalTodos - completedTodos;

  return (
    <div className="bg-indigo-600 p-6">
      <h1 className="text-2xl font-bold text-white text-center">My Todo List</h1>
      <div className="flex justify-between text-indigo-100 mt-2 text-sm">
        <span>Total: {totalTodos}</span>
        <span>Completed: {completedTodos}</span>
        <span>Pending: {pendingTodos}</span>
      </div>
    </div>
  );
};

export default TodoHeader;