import React from 'react';
import StepByStep from '../components/StepByStep';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

const Guide = () => {
  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <Link 
          to="/" 
          className="inline-flex items-center mb-6 text-indigo-600 hover:text-indigo-800 transition-colors"
        >
          <ArrowLeft size={20} className="mr-2" />
          Back to App
        </Link>
        
        <StepByStep />
      </div>
    </div>
  );
};

export default Guide;