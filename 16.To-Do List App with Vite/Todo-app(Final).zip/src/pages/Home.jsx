import React from 'react';
import TodoHeader from '../components/TodoHeader';
import TodoForm from '../components/TodoForm';
import TodoList from '../components/TodoList';
import Instructions from '../components/Instructions';

const Home = ({ todos, addTodo, toggleTodo, deleteTodo }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden">
        {/* Header */}
        <TodoHeader todos={todos} />

        {/* Add Todo Form */}
        <TodoForm onAdd={addTodo} />

        {/* Todo List */}
        <TodoList 
          todos={todos} 
          onToggle={toggleTodo} 
          onDelete={deleteTodo} 
        />

        {/* Footer */}
        <div className="bg-gray-50 p-4 text-center text-sm text-gray-500">
          Click on a task to mark it as completed
        </div>
      </div>
      
      {/* Instructions Component */}
      <Instructions />
    </div>
  );
};

export default Home;