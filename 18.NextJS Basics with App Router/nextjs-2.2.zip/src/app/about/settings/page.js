export default function Settings(){

    return(
        <>
            <h1> This is the Settings Page. </h1>
        </>
    )
}