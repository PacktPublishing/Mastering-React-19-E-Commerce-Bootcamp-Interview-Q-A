import AddUser from "@/screens/users/add";

export default function(){

    return(
        <>
            <AddUser/>
        </>
    )
}