import UsersScreen from "@/screens/users";

export default function UsersPage(){

    return(
        <>
            <UsersScreen/>
        </>
    )
}