import ProductTypes from "@/screens/product-type";

const ProductTypeManagement = ()=>{

    return(
        <div>
            <ProductTypes/>
        </div>
    )
}

export default ProductTypeManagement;