import EditProductType from "@/screens/product-type/edit";


const EditProductTypePage = ({searchParams})=>{
    return(
        <>
            <EditProductType searchParams={searchParams}/>
        </>
    )
}

export default EditProductTypePage;