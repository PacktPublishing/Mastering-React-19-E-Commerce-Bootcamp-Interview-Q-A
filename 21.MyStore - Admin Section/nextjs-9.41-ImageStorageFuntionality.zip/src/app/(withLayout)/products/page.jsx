import Products from "@/screens/products";


const ProductsManagement = ()=>{
    return(
        <>
            <Products/>
        </>
    );
};

export default ProductsManagement;