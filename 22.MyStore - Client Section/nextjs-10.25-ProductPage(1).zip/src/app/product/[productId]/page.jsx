import Product from "@/screens/product";


const ProductPage = ()=>{

    return(
        <>
            <Product/>
        </>
    )
}

export default ProductPage;