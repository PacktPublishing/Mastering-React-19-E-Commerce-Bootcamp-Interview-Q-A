import Image from "next/image";

export default function Home() {
  return (
    <h1>Home page of the Client Application</h1>
  );
}
