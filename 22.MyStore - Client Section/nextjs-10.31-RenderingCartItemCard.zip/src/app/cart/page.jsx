import Cart from "@/screens/cart";

const CartPage = ()=>{

    return(
        <>
            <Cart/>
        </>
    )
}

export default CartPage;