import SignUp from "@/screens/sign-up";

const SignUpPage = ()=>{

    return(
        <>
            <SignUp/>
        </>
    )
}

export default SignUpPage;