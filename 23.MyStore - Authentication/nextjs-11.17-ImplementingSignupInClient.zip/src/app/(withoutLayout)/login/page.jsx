const { default: Login } = require("@/screens/login")

const LoginPage = ()=>{

    return(
        <>
            <Login/>
        </>
    )
}

export default LoginPage;