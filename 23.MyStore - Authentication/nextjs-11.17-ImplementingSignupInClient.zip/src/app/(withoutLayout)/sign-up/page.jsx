import SignUp from "@/screens/sign-up";

const SignUpPage = ({searchParams})=>{

    return(
        <>
            <SignUp searchParams={searchParams}/>
        </>
    )
}

export default SignUpPage;