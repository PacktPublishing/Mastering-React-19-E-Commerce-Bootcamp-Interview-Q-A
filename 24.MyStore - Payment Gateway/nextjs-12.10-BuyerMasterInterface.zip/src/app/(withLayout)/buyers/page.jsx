import Buyers from "@/screens/buyers";

const BuyersPage = ()=>{
    return(
        <>
            <Buyers/>
        </>
    );
}

export default BuyersPage;