import Checkout from "@/screens/checkout";

const CheckoutPage = ()=>{

    return(
        <>
            <Checkout/>
        </>
    );
}

export default CheckoutPage;