import Login from "@/screens/login";

const LoginPage = async ()=>{

    return(
        <>
            <Login/>
        </>
    );
};

export default LoginPage;